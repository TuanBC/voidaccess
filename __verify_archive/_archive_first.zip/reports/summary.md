# Investigation Summary

**Query:** LockBit ransomware

**Created:** 2026-06-09T00:00:00Z

## Summary

LockBit infrastructure observed on multiple dark web forums.
